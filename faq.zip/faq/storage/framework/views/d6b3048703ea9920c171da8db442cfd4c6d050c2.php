<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3>
                <?php echo e($question->title); ?>

            </h3>
            <p>
                <?php echo e($question->text); ?>

                <?php if(Auth::check() && Auth::user()->id === $question->user_id): ?>
                    <span class="float-right">
                        <a href="<?php echo e(url('/showQuestion/'.$question->id.'/editQuestion')); ?>">edit</a>
                        <a href="<?php echo e(url('/showQuestion/'.$question->id.'/deleteQuestion')); ?>">delete</a>
                    </span>
                <?php endif; ?>
            </p>
            <p><?php echo e($question->created_at); ?><span class="float-right"><?php echo e($question->user->name); ?></span></p>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="col-md-12">
                <p>
                    <?php echo e($answer->text); ?>

                    <?php if(Auth::check() && Auth::user()->id === $answer->user_id): ?>
                        <span class="float-right">
                            <a href="<?php echo e(url('/showQuestion/'.$question->id.'/'.$answer->id.'/editAnswer')); ?>">edit</a>
                            <a href="<?php echo e(url('/showQuestion/'.$question->id.'/'.$answer->id.'/deleteAnswer')); ?>">delete</a>
                        </span>
                    <?php endif; ?>
                </p>
                <p><?php echo e($answer->created_at); ?><span class="float-right"><?php echo e($answer->user->name); ?></span></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </div>
    <?php if(Auth::check()): ?>
        <div class="row">
            <div class="col-md-12">
                <form method="POST" action="/showQuestion/<?php echo e($question->id); ?>/answer">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                    </div>
                    <div class="form-group">
                        <label>Answer</label>
                        <textarea name="text" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Answer</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>