<?php $__env->startSection('content'); ?>
    <div class="jumbotron margin-5">
        <h2 class="text-center main-color">
            <a href="<?php echo e(url('/ask')); ?>">Ask</a> us any questions. We will answer it!
        </h2>
        <?php if(!empty($lastQuestion)): ?>
            <h3 class="justified">
                <a href="<?php echo e(url('/question/'.$lastQuestion->id)); ?>"><?php echo e($lastQuestion->title); ?></a>
            </h3>
            <p class="text-right"><?php echo e($lastQuestion->user->name); ?></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>