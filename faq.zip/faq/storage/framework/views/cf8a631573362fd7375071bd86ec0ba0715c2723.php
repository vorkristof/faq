<?php $__env->startSection('content'); ?>
    <?php if($questions->isEmpty()): ?>
        <div class="jumbotron margin-5">
            <h2 class="text-center main-color">There is no question asked.</h2>
            <h3 class="text-center main-color"><a href="<?php echo e(url('/askQuestions')); ?>">Ask</a> us any questions.</h3>
        </div>
    <?php else: ?>
        <div class="row">
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="col-md-4">
                    <a href="<?php echo e($question->path()); ?>">
                        <?php echo e($question->title); ?><span class="float-right"><?php echo e(count($question->answers)); ?></span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>