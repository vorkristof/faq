<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>FAQ</title>

    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="/css/app.css">
    <link rel="stylesheet" href="/css/style.css">
</head>
<body class="background-color">
<div class="container main-color">

        <nav role="navigation" class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" data-target="#navbarCollapse" data-toggle="collapse" class="navbar-toggle">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <!-- Collection of nav links and other content for toggling -->
            <div id="navbarCollapse" class="collapse navbar-collapse">
                <?php if(Auth::check()): ?>
                    <ul class="nav nav-tabs nav-justified">
                        <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/')); ?>" onclick="">Home </a>
                        </li>
                        <li class="<?php echo e(Request::is('ask') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/ask')); ?>">Ask </a>
                        </li>
                        <li class="<?php echo e(Request::is('questions') ? 'active' : ''); ?>

                        <?php echo e(Request::is('question/*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/questions')); ?>">Questions </a>
                        </li>
                        <li><a href="<?php echo e(url('/logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                Logout
                            </a>

                            <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    </ul>
                <?php else: ?>
                    <ul class="nav nav-tabs nav-justified">
                        <li class="<?php echo e(Request::is('/') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/')); ?>">Home </a>
                        </li>
                        <li class="<?php echo e(Request::is('questions') ? 'active' : ''); ?>

                        <?php echo e(Request::is('question/*') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/questions')); ?>">Questions </a>
                        </li>
                        <li class="<?php echo e(Request::is('register') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/register')); ?>">Registration </a>
                        </li>
                        <li class="<?php echo e(Request::is('login') ? 'active' : ''); ?>">
                            <a href="<?php echo e(url('/login')); ?>">Log In</a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </nav>






    <?php echo $__env->yieldContent('content'); ?>

    <script src="/js/app.js"></script>
    <script src="/js/jquery-3.1.1.min.js"></script>
    <script src="/js/script.js"></script>
</div>
</body>
</html>
