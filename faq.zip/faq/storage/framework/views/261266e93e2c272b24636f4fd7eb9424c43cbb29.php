<?php $__env->startSection('content'); ?>
    <form method="POST" action="/showQuestion/<?php echo e($question->id); ?>/destroyQuestion">
        <?php echo e(method_field('DELETE')); ?>

        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <span>Do you want to delete this question?</span>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Delete</button>
            <button type="button" class="btn btn-primary" onClick="history.go(-1);return true;">Back</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>