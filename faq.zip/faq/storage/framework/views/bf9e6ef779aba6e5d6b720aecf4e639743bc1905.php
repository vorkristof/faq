<?php $__env->startSection('content'); ?>
    <form method="POST" action="/showQuestion/<?php echo e($question->id); ?>/updateQuestion">
        <?php echo e(method_field('PATCH')); ?>

        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
        </div>
        <div class="form-group">
            <textarea name="title" class="form-control"><?php echo e($question->title); ?></textarea>
        </div>
        <div class="form-group">
            <textarea name="text" class="form-control"><?php echo e($question->text); ?></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn main-btn">Edit</button>
            <button type="button" class="btn main-btn" onClick="history.go(-1);return true;">Back</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>