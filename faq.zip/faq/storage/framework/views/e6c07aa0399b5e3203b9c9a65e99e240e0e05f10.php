<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <form method="POST" action="/question/<?php echo e($question->id); ?>/<?php echo e($answer->id); ?>">
                <?php echo e(method_field('PATCH')); ?>

                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <textarea name="text" class="form-control" required><?php echo e($answer->text); ?></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn main-btn">Edit</button>
                    <button type="button" class="btn main-btn" onClick="history.go(-1);return true;">Back</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>