<?php $__env->startSection('content'); ?>
    <form method="POST" action="/showQuestion/<?php echo e($answer->id); ?>/updateAnswer">
        <?php echo e(method_field('PATCH')); ?>

        <?php echo e(csrf_field()); ?>

        <div class="form-group">
            <input type="hidden" name="question_id" value="<?php echo e($question->id); ?>">
        </div>
        <div class="form-group">
            <textarea name="text" class="form-control"><?php echo e($answer->text); ?></textarea>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary">Edit</button>
            <button type="button" class="btn btn-primary" onClick="history.go(-1);return true;">Back</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>