<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h3 class="justified">
                <?php echo e($question->title); ?>

            </h3>
            <?php if(Auth::check() && Auth::user()->id === $question->user_id): ?>
                <a class="btn" href="<?php echo e(url('/question/'.$question->id.'/edit')); ?>">edit</a>
                <a class="btn" href="<?php echo e(url('/question/'.$question->id.'/delete')); ?>">delete</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 justified">
            <p><?php echo e($question->text); ?></p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <p><?php echo e($question->created_at); ?><span class="float-right"><?php echo e($question->user->name); ?></span></p>
        </div>
    </div>
    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="row">
            <div class="col-md-12">
                <p class="justified">
                    <?php echo e($answer->text); ?>

                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p>
                    <?php if(Auth::check() && Auth::user()->id === $answer->user_id): ?>
                        <span class="float-right">
                            <a class="btn" href="<?php echo e(url('/question/'.$question->id.'/'.$answer->id.'/edit')); ?>">edit</a>
                            <a class="btn" href="<?php echo e(url('/question/'.$question->id.'/'.$answer->id.'/delete')); ?>">delete</a>
                        </span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p>
                    votes: <?php echo e($answer->votes); ?>

                    <?php if(Auth::check()): ?>
                        <span class="float-right">
                            <a class="btn" href="<?php echo e(url('/question/'.$question->id.'/'.$answer->id.'/upvote')); ?>">
                                <span class="glyphicon glyphicon-plus"></span>
                            </a>
                            <a class="btn" href="<?php echo e(url('/question/'.$question->id.'/'.$answer->id.'/downvote')); ?>">
                                <span class="glyphicon glyphicon-minus"></span>
                            </a>
                        </span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <p><?php echo e($answer->created_at); ?><span class="float-right"><?php echo e($answer->user->name); ?></span></p>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php if(Auth::check()): ?>
        <div class="row">
            <div class="col-md-12">
                <form method="POST" action="/question/<?php echo e($question->id); ?>/answer">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label>Answer</label>
                        <textarea name="text" class="form-control" required></textarea>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn main-btn">Answer</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>