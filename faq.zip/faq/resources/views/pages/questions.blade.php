@extends('main')

@section('content')
    @if($questions->isEmpty())
        <div class="jumbotron margin-5">
            <h2 class="text-center main-color">There is no question asked.</h2>
            <h3 class="text-center main-color"><a href="{{ url('/ask') }}">Ask</a> us any questions.</h3>
        </div>
    @else
		<div class="row">
			@foreach($questions as $question)
				<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
					<a href="{{ $question->path() }}" class="btn width-100">
						<p class="justified">{{ $question->title }}</p>
						<p class="light-color float-right">{{ count($question->answers) }}</p>
					</a>
				</div>
			@endforeach
		</div>
    @endif
@stop


